extern "C"
{
int _fltused = 1;

#ifndef _M_X64
float __declspec(naked) __cdecl _CIcos()
{
   _asm {
      fcos
      ret
   };
};

float __declspec(naked) __cdecl _CIsin()
{
   _asm {
      fsin
      ret
   };
};

float __declspec(naked) __cdecl _CIsqrt()
{
   _asm {
      fsqrt
      ret
   };
};
#endif 

};