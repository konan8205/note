#ifndef _ARGCARGV_H_
#define _ARGCARGV_H_

extern TCHAR ** _ppszArgv;

int __cdecl _ConvertCommandLineToArgcArgv( void );

#endif // _ARGCARGV_H_