#include <windows.h>

#pragma function(memset)

extern "C" void* __cdecl memset(void *pDst, int value, size_t size)
{
  char *pByte = (char *) pDst;
  char *pEnd = pByte + size;

  while (pByte!= pEnd) *pByte++ = value;
  
  return pDst;
}

