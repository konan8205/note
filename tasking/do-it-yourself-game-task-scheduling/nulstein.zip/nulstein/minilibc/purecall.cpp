#include <windows.h>

extern "C" int __cdecl _purecall()
{
	ExitProcess(-1);
	return 0;
}