#include <windows.h>

#pragma function(memcpy)

extern "C" void* __cdecl memcpy(void *pDst, const void *pSrc, size_t size)
{
  char *pByteIn  = (char *) pSrc;
  char *pByteOut = (char *) pDst;
  char *pEnd = pByteOut + size;

  while (pByteOut!= pEnd) *pByteOut++ = *pByteIn++;
  
  return pDst;
}

