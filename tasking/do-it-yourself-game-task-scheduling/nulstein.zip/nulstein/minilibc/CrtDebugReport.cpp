#include <windows.h>
#include <crtdbg.h>

#ifdef _DEBUG

#ifdef _UNICODE
int __cdecl _CrtDbgReportW(
        int				_ReportType,
        const wchar_t*	_Filename,
        int				_LineNumber,
        const wchar_t*	_ModuleName,
        const wchar_t*	_Format,
        ...)
{
	return 0;
}
#else
int __cdecl _CrtDbgReportA(
        int				_ReportType,
        const char*		_Filename,
        int				_LineNumber,
        const char*		_ModuleName,
        const char*		_Format,
        ...)
{
	return 0;
}
#endif

#endif