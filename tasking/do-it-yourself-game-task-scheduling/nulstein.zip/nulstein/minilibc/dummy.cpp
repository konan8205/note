int MiniLibcDummy()
{
	return 0;
}