#ifndef _NULSTEIN_CONFIG_H_
#define _NULSTEIN_CONFIG_H_

#define FULLSCREEN_DEFAULT		1		/* see Nulstein.cpp			*/ 
#define SINGLETHREADED			0		/* see TaskScheduler.cpp	*/ 
#define USE_FRAMEROOTTASK		1		/* see NulsteinWindow.cpp	*/ 
#define USE_PARALLELSORT		0		/* see DisplayList.cpp		*/ 

#endif // _NULSTEIN_CONFIG_H_