//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//

/////////////////////////////////////////////////////////////////////////////
// Based upon:
//
// Approximate Math Library for SSE / SSE2
//  Header File
//  Version 2.0
//  Author Alex Klimovitski, Intel GmbH
/////////////////////////////////////////////////////////////////////////////
#include <emmintrin.h>

#include "AMaths.h"
#include "AMaths_internal.h"

_PS_EXTERN_CONST(atan_t0, -0.91646118527267623468e-1f);
_PS_EXTERN_CONST(atan_t1, -0.13956945682312098640e1f);
_PS_EXTERN_CONST(atan_t2, -0.94393926122725531747e2f);
_PS_EXTERN_CONST(atan_t3,  0.12888383034157279340e2f);

_PS_EXTERN_CONST(atan_s0,  0.12797564625607904396e1f);
_PS_EXTERN_CONST(atan_s1,  0.21972168858277355914e1f);
_PS_EXTERN_CONST(atan_s2,  0.68193064729268275701e1f);
_PS_EXTERN_CONST(atan_s3,  0.28205206687035841409e2f);

