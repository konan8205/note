//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//

/////////////////////////////////////////////////////////////////////////////
// Based upon:
//
// Approximate Math Library for SSE / SSE2
//  Header File
//  Version 2.0
//  Author Alex Klimovitski, Intel GmbH
/////////////////////////////////////////////////////////////////////////////
#include <emmintrin.h>

#include "AMaths.h"
#include "AMaths_internal.h"

_PS_EXTERN_CONST(exp_hi,	88.3762626647949f);
_PS_EXTERN_CONST(exp_lo,	-88.3762626647949f);

_PS_EXTERN_CONST(exp_rln2, 1.4426950408889634073599f);

_PS_EXTERN_CONST(exp_p0, 1.26177193074810590878e-4f);
_PS_EXTERN_CONST(exp_p1, 3.02994407707441961300e-2f);

_PS_EXTERN_CONST(exp_q0, 3.00198505138664455042e-6f);
_PS_EXTERN_CONST(exp_q1, 2.52448340349684104192e-3f);
_PS_EXTERN_CONST(exp_q2, 2.27265548208155028766e-1f);
_PS_EXTERN_CONST(exp_q3, 2.00000000000000000009e0f);

_PS_EXTERN_CONST(exp_c1, 6.93145751953125e-1f);
_PS_EXTERN_CONST(exp_c2, 1.42860682030941723212e-6f);

