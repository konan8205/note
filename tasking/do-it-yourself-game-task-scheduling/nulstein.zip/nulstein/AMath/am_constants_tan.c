//-------------------------------------------------------------------------------------
//
// Copyright 2009 Intel Corporation
// All Rights Reserved
//
// Permission is granted to use, copy, distribute and prepare derivative works of this
// software for any purpose and without fee, provided, that the above copyright notice
// and this statement appear in all copies.  Intel makes no representations about the
// suitability of this software for any purpose.  THIS SOFTWARE IS PROVIDED "AS IS."
// INTEL SPECIFICALLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AND ALL LIABILITY,
// INCLUDING CONSEQUENTIAL AND OTHER INDIRECT DAMAGES, FOR THE USE OF THIS SOFTWARE,
// INCLUDING LIABILITY FOR INFRINGEMENT OF ANY PROPRIETARY RIGHTS, AND INCLUDING THE
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  Intel does not
// assume any responsibility for any errors which may appear in this software nor any
// responsibility to update it.
//

/////////////////////////////////////////////////////////////////////////////
// Based upon:
//
// Approximate Math Library for SSE / SSE2
//  Header File
//  Version 2.0
//  Author Alex Klimovitski, Intel GmbH
/////////////////////////////////////////////////////////////////////////////
#include <emmintrin.h>

#include "AMaths.h"
#include "AMaths_internal.h"

_PS_EXTERN_CONST(tan_p0, -1.79565251976484877988e7f);
_PS_EXTERN_CONST(tan_p1, 1.15351664838587416140e6f);
_PS_EXTERN_CONST(tan_p2, -1.30936939181383777646e4f);
	
_PS_EXTERN_CONST(tan_q0, -5.38695755929454629881e7f);
_PS_EXTERN_CONST(tan_q1, 2.50083801823357915839e7f);
_PS_EXTERN_CONST(tan_q2, -1.32089234440210967447e6f);
_PS_EXTERN_CONST(tan_q3, 1.36812963470692954678e4f);

_PS_EXTERN_CONST(tan_poleval, 3.68935e19f);

